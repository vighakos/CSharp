﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_Muzsika
{
    class Feladat
    {
        public static List<Muzsika> list = Olvas.Beolvas("file.csv");

        public static void _1()
        {
            int h = 0,
                m = 0,
                s = 0,
                tS = 0;

            for (int i = 0; i < list.Count; i++)
            {
                tS += list[i].Ido.Mp + (list[i].Ido.Perc * 60);
            }

            h = tS / 60 / 60;
            m = (tS / 60) - h * 60;
            s = tS - (h * 60 * 60) - m * 60;

            Console.WriteLine($"1. feladat: {h:00}:{m:00}:{s:00}");
        }

        public static void _2()
        {
            Console.WriteLine($"2. feladat: a legnépszerűbb zene: {list.Find(x => x.Nepszeruseg == list.Max(y => y.Nepszeruseg)).Eloado} - {list.Find(x => x.Nepszeruseg == list.Max(y => y.Nepszeruseg)).Cim}");
        }

        public static void _3()
        {
            List<string> felhasznalok = new List<string>();

            for (int i = 0; i < list.Count; i++)
            {
                if (!felhasznalok.Contains(list[i].Felhasznalo))
                {
                    felhasznalok.Add(list[i].Felhasznalo);
                }
            }

            int[] csillagok = new int[felhasznalok.Count];

            for (int i = 0; i < felhasznalok.Count; i++)
            {
                int db = 0;
                for (int g = 0; g < list.Count; g++)
                {
                    if (list[g].Felhasznalo == felhasznalok[i])
                    {
                        db++;
                    }
                }
                double esely = 100 * db / list.Count / 20;
                csillagok[i] = Convert.ToInt32(esely);
            }
            for (int i = 0; i < csillagok.Length; i++)
            {
                string oszlop = oszlopD(csillagok[i]);
                Console.WriteLine($"{felhasznalok[i]} - {csillagok[i] * 20}");
            }

        }

        private static string oszlopD(int szazalek)
        {
            string s = "";
            for (int i = 0; i < szazalek; i++)
                s += "*";

            return s;
        }

        public Feladat()
        {
            _1();
            _2();
            _3();
        }
    }
}
