﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_Muzsika
{
    class Program
    {
        static List<Muzsika> adatok = Olvas.Beolvas("file.csv");
        static void Main(string[] args)
        {
            new Feladat();

            Console.ReadKey(); //😂👌
        }
    }
}
