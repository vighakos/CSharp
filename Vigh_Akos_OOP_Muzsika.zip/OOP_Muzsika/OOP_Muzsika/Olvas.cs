﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_Muzsika
{
    class Olvas
    {
        static public List<Muzsika> Beolvas(string fajlNev)
        {
            List<Muzsika> adatok = new List<Muzsika>();

            try
            {
                StreamReader be = new StreamReader(fajlNev);
                be.ReadLine();

                while (!be.EndOfStream)
                    adatok.Add(new Muzsika(be.ReadLine().Split(';')));

                be.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

            return adatok;
        }
    }
}
