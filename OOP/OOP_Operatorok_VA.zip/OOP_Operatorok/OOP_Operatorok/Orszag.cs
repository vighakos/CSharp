﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_Operatorok
{
    class Orszag
    {
        public string Nev;
        public int Tamadok, Vedok;

        public Orszag(string nev)
        {
            Nev = nev;
            Tamadok = 0;
            Vedok = 0;
        }
    }
}
