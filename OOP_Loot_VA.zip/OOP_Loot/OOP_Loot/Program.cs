﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_Loot
{
    class Program
    {
        static void Main(string[] args)
        {
            Feladatok._1();
            Feladatok._2();
            Feladatok._3();
            Feladatok._4();
            Feladatok._5();
            Feladatok._6();

            Console.ReadKey();
        }
    }
}
