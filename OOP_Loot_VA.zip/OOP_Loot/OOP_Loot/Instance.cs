﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_Loot
{
    class Instance
    {
        public string Nev { get; set; }
        public int Db { get; set; }

        public Instance(string nev)
        {

        }
    }
}
