﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_Foci
{
    class Program
    {
        static List<Jatekos> jatekosok = Olvas.Beolvas("foci.txt");
        static void Main(string[] args)
        {
            ElsoFeladat();
            MasodikFeladat();
            HarmadikFeladat();

            Console.ReadKey();
        }

        private static void HarmadikFeladat()
        {
            Console.WriteLine("3. feladat: Csapatonkénti játékosok száma: ");

            List<string> csapatok = new List<string>();

            for (int i = 0; i < jatekosok.Count; i++)
            {
                if (!csapatok.Contains(jatekosok[i].Klub.Nev))
                {
                    csapatok.Add(jatekosok[i].Klub.Nev);
                }
            }

            int[] csapatonkent = new int[csapatok.Count];

            for (int i = 0; i < jatekosok.Count; i++)
            {
                for (int j = 0; j < csapatok.Count; j++)
                {
                    if (jatekosok[i].Klub.Nev == csapatok[j])
                    {
                        csapatonkent[j]++;
                    }
                }
            }

            for (int i = 0; i < csapatok.Count; i++)
            {
                Console.WriteLine($"\t{csapatok[i]} - {csapatonkent[i]}");
            }
        }

        private static void MasodikFeladat()
        {
            Console.Write($"2. feladat: Adj meg egy kort: ");

            int eletkor = Convert.ToInt32(Console.ReadLine());
            int ossz = 0;

            for (int i = 0; i < jatekosok.Count; i++)
            {
                if (jatekosok[i].Eletkor == eletkor) ossz++;
            }

            Console.WriteLine($"\t{ossz} játékos ennyi idős");
        }

        private static void ElsoFeladat()
        {
            Console.WriteLine($"1. feladat: a fájl {jatekosok.Count} játékost tartalmaz.");
        }
    }
}
