﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_Epuletek
{
    class Program
    {
        public static List<Epulet> adatok = Olvas.Beolvas("epuletek.csv");
        static void Main(string[] args)
        {
            F1(); //1. Hány épületről ismerünk minden adatot?
            F2(); //2. Hány olyan épület van, aminek nem ismétlődik a neve?
            F3(); //3. Az épületek hány százaléka van Budapesten?
            F4(); //4. Írd ki a 75, vagy annál magasabb épületek átlagos magasságát!

            Console.ReadKey();
        }

        private static void F4()
        {
            List<Epulet> magasabbak = new List<Epulet>();

            for (int i = 0; i < adatok.Count; i++)
            {
                if (adatok[i].Magassag >= 75)
                {
                    magasabbak.Add(adatok[i]);
                }
            }

            double ossz = 0;
            for (int i = 0; i < magasabbak.Count; i++)
            {
                ossz += magasabbak[i].Magassag;
            }

            Console.WriteLine($"4. feladat: 75 méternél magasabb épületek átlaga: {ossz / magasabbak.Count:0.00}m");
        }

        private static void F3()
        {
            double ossz = 0;
            for (int i = 0; i < adatok.Count; i++)
            {
                if (adatok[i].Telepules.Contains("Budapest"))
                {
                    ossz++;
                }
            }

            Console.WriteLine($"3. feladat: Az épületek {ossz * 100 / adatok.Count}%-a van Budapesten");
        }

        private static void F2()
        {
            int db = 0;
            
            for (int i = 0; i < adatok.Count; i++)
            {
                bool talalat = false;
                for (int j = 0; j < adatok.Count; j++)
                {
                    if (adatok[i].Nev == adatok[j].Nev && i!=j)
                    {
                        talalat = true;
                    }
                }

                if (!talalat)
                {
                    db++;
                }
            }

            Console.WriteLine($"2. feladat: {db} egyedi nevű épület van");
        }

        private static void F1()
        {
            int db = 0;

            for (int i = 0; i < adatok.Count; i++)
            {
                if (adatok[i].Magassag != 0 && 
                    adatok[i].Emeletek != 0 && 
                    adatok[i].Ev.Kezdo != 0 && 
                    adatok[i].Ev.Veg != 0)
                {
                    db++;
                }
            }

            Console.WriteLine($"1. feladat: {db} épületről ismerünk minden adatot"); //végeredmény: 15
        }
    }
}
